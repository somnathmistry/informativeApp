package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.example.aictech.R;

public class splash_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);
        Thread splashh = new Thread(){
            public void run(){
                try{

                    sleep(3000);
                    Intent intent = new Intent(getApplicationContext(), LaunchingActivity.class);
                    startActivity(intent);
                    finish();

                }catch (Exception e){

                }
            }
        };
        splashh.start();
    }
}
