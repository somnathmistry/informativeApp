package com.example.aictech.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.aictech.R;

public class LaunchingActivity extends AppCompatActivity {
    private ConstraintLayout eduCon, softCon, spiderCon, roboCon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launching);

        eduCon = findViewById(R.id.cardcseId);
        softCon = findViewById(R.id.cardEtcId);
        spiderCon = findViewById(R.id.cardCseId);
        roboCon = findViewById(R.id.carddigitelId);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                eduCon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }
                });
            }
        };
        Thread threadEdu = new Thread(runnable);
        threadEdu.start();
        eduCon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        softCon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LiveClass.class);
                intent.putExtra("wa", "https://www.aictkolkata.com/");
                startActivity(intent);
            }
        });
        spiderCon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LiveClass.class);
                intent.putExtra("wa", "http://www.examspiders.co.in/home");
                startActivity(intent);
            }
        });
        roboCon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LiveClass.class);
                intent.putExtra("wa", "http://www.robospark.co/#");
                startActivity(intent);
            }
        });

    }

    @Override
    public void onBackPressed() {

//        fragment = new HomeFragment();
//        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit AICT app?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        LaunchingActivity.super.onBackPressed();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
