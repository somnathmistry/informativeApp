package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.aictech.Models.GalleryData;
import com.example.aictech.Models.GalleryResponse;
import com.example.aictech.R;
import com.example.aictech.Utilities.ApiClient;
import com.example.aictech.Utilities.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GalleryActivity extends AppCompatActivity {
    private static final String TAG = "GalleryActivity";

    GridView gridView;
    ApiInterface apiInterface;
    List<GalleryData> galleryDatas;
    GridAdapters gridAdapters;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        gridView = findViewById(R.id.gridview);

        Call<GalleryResponse> call = ApiClient.apiInterface().getGallery();
        call.enqueue(new Callback<GalleryResponse>() {
            @Override
            public void onResponse(Call<GalleryResponse> call, Response<GalleryResponse> response) {

                if (response.isSuccessful()) {
                    galleryDatas = response.body().getData();

                    Toast.makeText(GalleryActivity.this, "Loding Images", Toast.LENGTH_SHORT).show();
                    gridAdapters = new GridAdapters(galleryDatas, GalleryActivity.this);
                    gridView.setAdapter(gridAdapters);


                    gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent intent = new Intent(getApplicationContext(), GallaryDetailActivity.class);
                            intent.putExtra("img", gridAdapters.galleryData.get(position).getImage());

                            startActivity(intent);
                        }
                    });
                } else {
                    Toast.makeText(GalleryActivity.this, "Gallery is Empty", Toast.LENGTH_SHORT).show();
                }

                assert response.body() != null;
                Log.i("Response..", "onResponse: " + response.body().getResponse());
            }
            @Override
            public void onFailure(Call<GalleryResponse> call, Throwable t) {

                try {
                    Toast.makeText(GalleryActivity.this, "Slow Internet", Toast.LENGTH_SHORT).show();
                } catch (Exception ignored) {

                }
            }
        });

    }

    public class GridAdapters extends BaseAdapter {
        public List<GalleryData> galleryData;
        public Context context;

        public GridAdapters(List<GalleryData> galleryData, Context context) {
            this.galleryData = galleryData;
            this.context = context;
        }

        @Override
        public int getCount() {
            return galleryData.size();
        }

        @Override
        public Object getItem(int position) {
            return 0;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view = LayoutInflater.from(context).inflate(R.layout.gallery_items, null);
            ImageView image = view.findViewById(R.id.imageGride);

            Glide.with(context)
                    .load(galleryData.get(position).getImage())
                    .into(image);
            return view;
        }
    }
}
