package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.aictech.R;

public class FinalyearProjectActivity extends AppCompatActivity {
    private Button clanB, webB, iotdevB, embedB, corejavaB, advjavaB, androidB,
            netB, pythonB, iotAiB, buyproject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalyear_project);

        clanB = findViewById(R.id.butid);
        webB = findViewById(R.id.butid2);
        iotdevB = findViewById(R.id.butid3);
        embedB = findViewById(R.id.butid4);
        corejavaB = findViewById(R.id.butid5);
        advjavaB = findViewById(R.id.butid6);
        androidB = findViewById(R.id.butid7);
        netB = findViewById(R.id.butid8);
        pythonB = findViewById(R.id.butid9);
        iotAiB = findViewById(R.id.butid10);
        buyproject = findViewById(R.id.buyproject);

        buyproject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Payment.class));
            }
        });

        clanB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","C Language Project");
                intent.putExtra("b","1. HOSPITAL MANAGEMENT SYSTEM\n" +
                        "2. CALENDAR\n" +
                        "3. CUSTOMER BILLING SYSTEM\n" +
                        "4. SCORESHEET\n" +
                        "5. SCHOOL BILLING SYSTEM");
                startActivity(intent);
            }
        });

        webB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","Web Development Project");
                intent.putExtra("b","1. MOVIE RESERVATION SYSTEM\n" +
                        "2. LIBRARY MANAGEMENT SYSTEM\n" +
                        "3. FLIGHT RESERVATION SYSTEM\n" +
                        "4. CAMPUS INFORMATION\n" +
                        "5. BANKING SYSTEM\n" +
                        "6. GLOBAL CHAT SERVER\n" +
                        "7. BUS TICKET RESERVATION\n" +
                        "8. Railway Reservation System\n" +
                        "9. Resort Management & Online Booking System\n" +
                        "10. Travel & Tourism");
                startActivity(intent);
            }
        });

        iotdevB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","IOT Development Project");
                intent.putExtra("b","1. SMS (GSM) controlled distant industrial appliances control\n" +
                        "2. SCADA controlled industrial appliances.\n" +
                        "3. Distant Industrial appliances control using IOT\n" +
                        "4. Digital weighing machine with automated LPG gas booking system using Embedded System\n" +
                        "5. CNC machine\n" +
                        "6. Quadcopter\n" +
                        "7. Smart City\n" +
                        "8. Smart EVM\n" +
                        "9. Smart Blind person’s Stick\n" +
                        "10. Smart wheel chair for Handicapped\n" +
                        "11. Automated Sign language to voice machine\n" +
                        "12. Smart Home Automation using Smart Phone\n" +
                        "13. Classroom Power Consumption Control\n" +
                        "14. Automated speed regulation of Induction Motor(Commercial fans)\n" +
                        "15. CNC machine\n" +
                        "16. Intelligent Magic Eye");
                startActivity(intent);
            }
        });

        embedB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","Embedded System Circuit Development Project");
                intent.putExtra("b","1. automatic wireless health Monitoring System\n" +
                        "\n" +
                        "2. line following  robotic vehicle\n" +
                        "\n" +
                        "3. tv remote operated  domestic /motor/industrial appliances control\n" +
                        "\n" +
                        "4. password based circuit  breaker\n" +
                        "\n" +
                        "5. street light that glow on detecting vehicles movement\n" +
                        "\n" +
                        "6. gsm based monthly energy meter billing via sms\n" +
                        "\n" +
                        "7. security system  with user changeable  password\n" +
                        "\n" +
                        "8. DTMF using appliances control\n" +
                        "\n" +
                        "9. Automatic solar tracker\n" +
                        "\n" +
                        "10. wireless electronics  notice board using gsm\n" +
                        "\n" +
                        "11. eletronics Voting  Machine\n" +
                        "\n" +
                        "12. RF Based  home automation system\n" +
                        "\n" +
                        "13.controling and monitoring of green house agriculture system\n" +
                        "\n" +
                        "14. bidirectional visitor counter using 8051\n" +
                        "\n" +
                        "15. automatic temperature controlled speed regulation of induction motor\n" +
                        "\n" +
                        "16. CNC machine\n" +
                        "\n" +
                        "17. biometric  voting machine\n" +
                        "\n" +
                        "18. automatic street light controller circuit using relay and LDR\n" +
                        "\n" +
                        "19. Smart blind stick\n" +
                        "\n" +
                        "20. buck chopper\n" +
                        "\n" +
                        "21. bust chopper\n" +
                        "\n" +
                        "22. INDUSTRIAL appliances control using SCADA\n" +
                        "\n" +
                        "23. Heart beat monitoring system\n" +
                        "\n" +
                        "24. Gesture control robot\n" +
                        "\n" +
                        "25. Automatic Water level indicator,with motor control and pump operation");
                startActivity(intent);
            }
        });

        corejavaB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","Core Java Development Project");
                intent.putExtra("b","1. STOCK MANAGEMENT SYSTEM\n" +
                        "2. LEAVE MANAGEMENT SYSTEM\n" +
                        "3. ONLINE MEDICAL STORE\n" +
                        "4. MOBILE BILLING\n" +
                        "5. QUIZ CONTEST\n" +
                        "6. STUDENT MANAGEMENT SYSTEM\n" +
                        "7. EXPENSE MANAGER\n" +
                        "8. SMART CITY\n" +
                        "9. Inventory Management system\n" +
                        "10. Seating Arrangements System\n" +
                        "11. File& image Cryptography");
                startActivity(intent);
            }
        });

        advjavaB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","Advance Java Development Project");
                intent.putExtra("b","1. BUG TRACKING SYSTEM\n" +
                        "2. ONLINE EXAM SYSTEM\n" +
                        "3. RAILWAY RESERVATION SYSTEM\n" +
                        "4. ONLINE FOOD ORDER\n" +
                        "5. ASSET MANAGEMENT MODULE\n" +
                        "6. TOURS & TRAVELS MANAGEMENT\n" +
                        "7. CAB BOOKING SERVICE\n" +
                        "8. CV BUILDER\n" +
                        "9. E-JANSEVA\n" +
                        "10. INFORMATION GATHER FOR EMP AND JOBSEEKERS\n" +
                        "11. INNOVATIVE SCHEDULER\n" +
                        "12. LOST OF ARTICELS & LETTERS RECONCILATION SYSTEM\n" +
                        "13. MY CRM\n" +
                        "14. ONLINE BANKING SYSTEM\n" +
                        "15. ONLINE COMPLAINT REGISTRATION\n" +
                        "16. ONLINE STORE\n" +
                        "17. HIRE A CAB\n" +
                        "18. NET MALL\n" +
                        "19. ONLINE FLIGHT RESERVATION SYSTEM\n" +
                        "20. ONLINE LIBRARY\n" +
                        "21. ONLINE BOOK STORE");
                startActivity(intent);
            }
        });

        androidB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","Android Application Development Project");
                intent.putExtra("b","");
                startActivity(intent);
            }
        });

        netB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a",".NET ( C# with MySQL )");
                intent.putExtra("b","1. ONLINE ART GALLERY\n" +
                        "2. BLOOD BANK MANAGEMENT SYSTEM\n" +
                        "3. HR MANAGEMENT SYSTEM\n" +
                        "4. TPO MANAGEMENT\n" +
                        "5. ONLINE SHOPPING\n" +
                        "6. SCHOOL MANAGEMENT SYSTEM\n" +
                        "7. ONLINE BOOK SHOPPING\n" +
                        "8. SOCIAL NETWORKING AND CHAT SERVER\n" +
                        "9. DURGAPUR CITY\n" +
                        "10. GMAIL SERVICE\n" +
                        "11. SHOPPING POINT\n" +
                        "12. TECHNICAL SUPPORT SYSTEM\n" +
                        "13. E-commerce websites\n" +
                        "14. Tours & Travel\n" +
                        "15. Internet banking");
                startActivity(intent);
            }
        });

        pythonB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","Python Development Project");
                intent.putExtra("b","1. CINEMA TICKET\n" +
                        "2. Online Sports Turf Playground Booking System\n" +
                        "3. Online College Admission Management System Project\n" +
                        "4. Online Shoes Shopping Website Project\n" +
                        "5. Online Employee Payroll Management System Project\n" +
                        "6. Online Grocery Recommender System Using Collborative Filtering");
                startActivity(intent);
            }
        });

        iotAiB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ProjectDetailsActivity.class);
                intent.putExtra("a","IOT AI EMBEDDED Development Project");
                intent.putExtra("b","1. SMS (GSM) controlled distant industrial appliances control\n" +
                        "2. SCADA controlled industrial appliances.\n" +
                        "3. Distant Industrial appliances control using IOT\n" +
                        "4. Digital weighing machine with automated LPG gas booking system using Embedded System\n" +
                        "5. CNC machine\n" +
                        "6. Quadcopter\n" +
                        "7. Smart City\n" +
                        "8. Smart EVM\n" +
                        "9. Smart Blind person’s Stick\n" +
                        "10. Smart wheel chair for Handicapped\n" +
                        "11.eletronics Voting  Machine\n" +
                        "\n" +
                        "12. RF Based  home automation system\n" +
                        "\n" +
                        "13. controling and monitoring of green house agriculture system\n" +
                        "\n" +
                        "14. bidirectional visitor counter using 8051\n" +
                        "\n" +
                        "15. automatic temperature controlled speed regulation of induction motor\n" +
                        "\n" +
                        "16. CNC machine\n" +
                        "\n" +
                        "17. biometric  voting machine\n" +
                        "\n" +
                        "18. automatic street light controller circuit using relay and LDR\n" +
                        "\n" +
                        "19. Smart blind stick\n" +
                        "\n" +
                        "20. buck chopper\n" +
                        "\n" +
                        "21. bust chopper");
                startActivity(intent);
            }
        });
    }
}
