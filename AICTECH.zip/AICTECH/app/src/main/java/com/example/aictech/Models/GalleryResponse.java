package com.example.aictech.Models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GalleryResponse {

    @Expose
    @SerializedName("data")
    private List<GalleryData> data;
    @Expose
    @SerializedName("response")
    private String response;

    public GalleryResponse(List<GalleryData> data, String response) {
        this.data = data;
        this.response = response;
    }

    public List<GalleryData> getData() {
        return data;
    }

    public void setData(List<GalleryData> data) {
        this.data = data;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
