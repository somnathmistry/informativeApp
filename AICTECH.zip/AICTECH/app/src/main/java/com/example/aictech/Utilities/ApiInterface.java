package com.example.aictech.Utilities;

import com.example.aictech.Models.GalleryResponse;
import com.example.aictech.Models.PopupModel;
import com.example.aictech.Models.ProjectSlider;
import com.example.aictech.Models.TopSlider;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("slider.php")
    Call<List<TopSlider>> getSlider();

    @GET("project.php")
    Call<List<ProjectSlider>> getProjectSlider();

    @GET("gallery.php")
    Call<GalleryResponse> getGallery();

    @GET("slider.php")
    Call<List<PopupModel>> getPopUpSlider();
}
