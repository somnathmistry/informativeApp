package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import com.example.aictech.R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.Toast;


public class CourseDetailsActivity extends AppCompatActivity {
    private TextView coursename, coursefee, become;
    Spinner courseduration;
    private Button coursedetailId;
    ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        ImageView courseImage = findViewById(R.id.imageId);
        coursename = findViewById(R.id.textone);
        courseduration = findViewById(R.id.couredurationtxt);
        courseduration.setBackgroundColor(Color.GRAY);
//        courseduration.getScrollBarSize();
//        TextView spinnerText = (TextView) courseduration.getChildAt(0);
//        spinnerText.setTextColor(Color.WHITE);

        coursefee = findViewById(R.id.coursefee);
        become = findViewById(R.id.become);

        coursedetailId = findViewById(R.id.csereg);
        coursedetailId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),RegisterActivity.class));
            }
        });


        String name = getIntent().getStringExtra("a");
        String price = getIntent().getStringExtra("c");
        String becomStr = getIntent().getStringExtra("d");

        String image = getIntent().getStringExtra("im");
        assert image != null;
        int i = Integer.parseInt(image);

        coursename.setText(name);
        coursefee.setText(price);
        become.setText(becomStr);
        courseImage.setImageResource(i);




        expListView = findViewById(R.id.lvExp);

        // preparing list data
        prepareListData();

        listAdapter = new com.example.aictech.Adapters.ExpandableListAdapter(this, listDataHeader, listDataChild);

        // setting list adapter
        expListView.setAdapter(listAdapter);
    }

    /*
     * Preparing the list data
     */
    private void prepareListData() {
        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();


        String learnStr = getIntent().getStringExtra("wlearn");
        String projectStr = getIntent().getStringExtra("pro");
        String reqStr = getIntent().getStringExtra("req");
        String desStr = getIntent().getStringExtra("e");
        String futureStr = getIntent().getStringExtra("f");

        //Toast.makeText(this, "Respons  "+learnStr+reqStr+desStr+futureStr, Toast.LENGTH_SHORT).show();

        // Adding child data
        listDataHeader.add("What you'll learn");
        listDataHeader.add("Project List");
        listDataHeader.add("Prerequisite");
        listDataHeader.add("Description");
        listDataHeader.add("Future Scope");


        // Adding child data
        List<String> wlearn = new ArrayList<String>();
        wlearn.add(learnStr);

        List<String> project = new ArrayList<String>();
        project.add(projectStr);


        List<String> req = new ArrayList<String>();
        req.add(reqStr);


        List<String> des = new ArrayList<String>();
        des.add(desStr);


        List<String> future = new ArrayList<String>();
        future.add(futureStr);


        listDataChild.put(listDataHeader.get(0), wlearn); // Header, Child data
        listDataChild.put(listDataHeader.get(1), project);
        listDataChild.put(listDataHeader.get(2), req);
        listDataChild.put(listDataHeader.get(3), des);
        listDataChild.put(listDataHeader.get(4), future);
    }
}
