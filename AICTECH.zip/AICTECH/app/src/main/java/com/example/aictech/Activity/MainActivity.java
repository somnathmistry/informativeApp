package com.example.aictech.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.example.aictech.Fragments.AboutFragment;
import com.example.aictech.Fragments.ContactFragment;
import com.example.aictech.Fragments.CourseFragment;
import com.example.aictech.Fragments.HomeFragment;
import com.example.aictech.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import java.util.Objects;
import hotchemi.android.rate.AppRate;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    Toolbar toolbar;
    NavigationView navigationView;
    Dialog popdilog;
    Fragment fragment = null;
    ViewPager popViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.slide_navigation);


        try {
            Thread threadpop = new Thread((Runnable) popViewPager);
            threadpop.start();
        } catch (Exception e) {
            e.printStackTrace();
        }


        //rate app
        rateUsMenu();

        final DrawerLayout drawerLayout = findViewById(R.id.nav);
        toolbar = findViewById(R.id.toolbar);
        navigationView = findViewById(R.id.navview);
        popdilog = new Dialog(this);

        final String img = Integer.toString(R.drawable.workshopmen);
        final String imgin = Integer.toString(R.drawable.workshopmen);


        getPopup();

        Runnable runnable2 = new Runnable() {
            @Override
            public void run() {
                navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                        int id = menuItem.getItemId();

                        switch (id) {
                            case R.id.demoClassMn:
                                Intent intent = new Intent(getApplicationContext(), LiveClass.class);
                                intent.putExtra("wa", "https://aictech.co.in/Register/getDemoClass.php");
                                startActivity(intent);
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.onlineMenu:
                                Intent intentOn = new Intent(getApplicationContext(), LiveClass.class);
                                intentOn.putExtra("wa", "https://aictech.co.in/register/summertraining.php");
                                startActivity(intentOn);
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.paymentMenu:
                                startActivity(new Intent(getApplicationContext(), RegPaymentActivity.class));
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.live:
                                Intent intent0 = new Intent(getApplicationContext(), LiveClass.class);
                                intent0.putExtra("wa", "https://aictech.co.in/Register/liveClass.php");
                                startActivity(intent0);
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.coursemenu:
                                fragment = new CourseFragment();
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.workshopmenu:
                                Intent intentw = new Intent(getApplicationContext(), WorkshopActivity.class);
                                intentw.putExtra("a", "WORKSHOP");
                                intentw.putExtra("b", img);
                                startActivity(intentw);
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.intermenu:
                                Intent intent1 = new Intent(getApplicationContext(), InternshipActivity.class);
                                intent1.putExtra("a", "INTERNSHIP");
                                intent1.putExtra("b", imgin);
                                startActivity(intent1);
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.industrialmenu:
                                Intent intent2 = new Intent(getApplicationContext(), IndustrialTrainingActivity.class);
                                intent2.putExtra("a", "Industrial Training ");
                                intent2.putExtra("b", imgin);
                                startActivity(intent2);
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.finalyearmenu:
                                startActivity(new Intent(getApplicationContext(), FinalyearProjectActivity.class));
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.gallery:
                                Toast.makeText(MainActivity.this, "Clicked " + id, Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), GalleryActivity.class));
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.socialmenu:
                                getSocialMenu();
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.sharemenu:
                                Intent shareintent = new Intent();
                                shareintent.setAction(Intent.ACTION_SEND);
                                shareintent.putExtra(Intent.EXTRA_TEXT, "Download AICT app");
                                shareintent.setType("text/plain");
                                startActivity(Intent.createChooser(shareintent, "Share With"));
                                drawerLayout.closeDrawers();
                                break;
                            case R.id.ratemenu:
                                rateUs();
                                drawerLayout.closeDrawers();
                                break;

                        }
                        return true;
                    }
                });
            }
        };

        try {
            Thread thread = new Thread(runnable2);
            thread.start();
        } catch (Exception e) {
            e.printStackTrace();
        }


        setSupportActionBar(toolbar);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        Fragment fragment = new HomeFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        int id = menuItem.getItemId();

        switch (id) {

            case R.id.bottom_nav_home:
                fragment = new HomeFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
                break;
            case R.id.bottom_nav_course:
                fragment = new CourseFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
                break;
            case R.id.bottom_nav_contact:
                fragment = new ContactFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
                break;
            case R.id.bottom_nav_about:
                fragment = new AboutFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
                break;
        }
        return true;
    }


    public void rateUsMenu() {
        AppRate.with(MainActivity.this)
                .setInstallDays(1)
                .setLaunchTimes(3)
                .setRemindInterval(2)
                .monitor();

        AppRate.showRateDialogIfMeetsConditions(MainActivity.this);
        AppRate.with(MainActivity.this).clearAgreeShowDialog();
        //AppRate.with(MainActivity.this).showRateDialog(MainActivity.this);
    }

    public void rateUs() {
        AppRate.with(MainActivity.this)
                .setInstallDays(1)
                .setLaunchTimes(3)
                .setRemindInterval(2)
                .monitor();

        AppRate.showRateDialogIfMeetsConditions(MainActivity.this);
        AppRate.with(MainActivity.this).clearAgreeShowDialog();
        AppRate.with(MainActivity.this).showRateDialog(MainActivity.this);
    }

    public void getSocialMenu() {
        TextView closetxt;
        LinearLayout weblin, fblin, instalin, twtlin, skyplin, linklin;
        popdilog.setContentView(R.layout.popupactivity);
        Objects.requireNonNull(popdilog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popdilog.show();
        closetxt = popdilog.findViewById(R.id.closeId);
        weblin = popdilog.findViewById(R.id.webpop);
        fblin = popdilog.findViewById(R.id.fbpop);
        instalin = popdilog.findViewById(R.id.instapop);
        twtlin = popdilog.findViewById(R.id.twtpop);
        skyplin = popdilog.findViewById(R.id.skyppop);
        linklin = popdilog.findViewById(R.id.linkpop);

        closetxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popdilog.dismiss();
            }
        });
        weblin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent socialintent = new Intent();
                socialintent.setAction(Intent.ACTION_VIEW);
                socialintent.setData(Uri.parse("https://aictech.co.in/"));
                startActivity(socialintent);

            }
        });
        fblin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/AICT248/")));
                } catch (Exception ignored) {
                }
            }
        });
        instalin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/aict_pvt_ltd/")));
                } catch (Exception ignored) {
                }

            }
        });
        twtlin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/AICTInnovators")));
                } catch (Exception ignored) {
                }

            }
        });
        skyplin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://join.skype.com/invite/fRQQ0kneqRor")));
                } catch (Exception ignored) {
                }

            }
        });
        linklin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent socialintent = new Intent();
                socialintent.setAction(Intent.ACTION_VIEW);
                socialintent.setData(Uri.parse("https://www.facebook.com/"));
                startActivity(socialintent);
            }
        });
    }

    public void getPopup() {
        TextView closetxt;
        popdilog.setContentView(R.layout.adpopup);
        popViewPager = findViewById(R.id.popupViewId);


        Objects.requireNonNull(popdilog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popdilog.show();

        //getPopSlider();
        //getImagesForSlider();


        closetxt = popdilog.findViewById(R.id.closeId);
        closetxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popdilog.dismiss();
            }
        });
    }
}
