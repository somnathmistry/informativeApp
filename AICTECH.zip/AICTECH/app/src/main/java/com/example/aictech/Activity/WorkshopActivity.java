package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.aictech.R;

public class WorkshopActivity extends AppCompatActivity {

    private Button ardinoBn, pythonBn, roboBn, dataBn, mlBn, vehicleBn, iotBn, hackBn, pcbBn, htmlBn, mcBn, androidBn, buyproject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workshop);

        ardinoBn = findViewById(R.id.butid);
        pythonBn = findViewById(R.id.butid2);
        roboBn = findViewById(R.id.butid3);
        dataBn = findViewById(R.id.butid4);
        mlBn = findViewById(R.id.butid5);
        vehicleBn = findViewById(R.id.butid6);
        iotBn = findViewById(R.id.butid7);
        hackBn = findViewById(R.id.butid8);
        pcbBn = findViewById(R.id.butid9);
        htmlBn = findViewById(R.id.butid10);
        mcBn = findViewById(R.id.butid01);
        androidBn = findViewById(R.id.butid02);
        buyproject = findViewById(R.id.buyproject);

        buyproject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),RegisterActivity.class));
            }
        });

        ardinoBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Introduction to Arduino");
                intent.putExtra("b","Workshop on Introduction to Arduino");
                intent.putExtra("c","Suitable For: 1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Arduino Microcontrollers\n" +
                        "2. Basic Anatomy of Arduino\n" +
                        "3. Getting Used to the Arduino IDE\n" +
                        "4. Programming with Arduino\n" +
                        "5. Blinking LEDs on Breadboard in a pattern\n" +
                        "6. PWM Control and Controlling brightness of the LEDs\n" +
                        "7. Detecting Switch Inputs with a Tact Switch\n" +
                        "8. Basic Light Sensor Designing with an LDR\n" +
                        "9. Introduction to Serial Monitoring\n" +
                        "10. Introduction to ADC and Reading Sensor Values\n" +
                        "11. Building an Embedded Application\n\n" +
                        " * KIT will be provided to participants (in a Group of 4 or 5) for Practicals during Workshop.");
                startActivity(intent);
            }
        });
        pythonBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Python Programming Language.\n");
                intent.putExtra("b","Workshop on Python Programming Language");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Python Introduction\n" +
                        "2. Python Installation\n" +
                        "3. Basics of Python\n" +
                        "4. Loops and Operators\n" +
                        "5. Data Structure in Python\n" +
                        "6. Functions in Python\n" +
                        "7. Modules in Python");
                startActivity(intent);
            }
        });
        roboBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Line Following Robot using Arduino\n");
                intent.putExtra("b","Workshop on Line Following Robot using Arduino");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Participant should have knowledge of Programming Language (at least C Language)]");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Arduino Microcontrollers\n" +
                        "2. Getting Used to the Arduino IDE\n" +
                        "3. Basics of Electronics\n" +
                        "4. Basics of Programming with Arduino\n" +
                        "5. Blinking an LED\n" +
                        "6. Reading values from an IR sensor\n" +
                        "7. Controlling brightness of a LED\n" +
                        "8. Designing a Line Following Sensor with IR\n" +
                        "9. Basic Electronics concepts of sensors\n" +
                        "10. Interfacing a motor driver to the Arduino\n" +
                        "11. Line Following Concepts\n" +
                        "12. Building the Line Follower\n\n" +
                        " * KIT will be provided to participants (in a Group of 4 or 5) for Practicals during Workshop.\n");
                startActivity(intent);
            }
        });
        dataBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Data Analytics with Python");
                intent.putExtra("b","Workshop on Data Analytics with Python");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Basic Knowledge of Python Programming will be helful.]");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Data Analytics\n" +
                        "2. Real Life Applications\n" +
                        "3. Setting up the tools\n" +
                        "4. Numpy\n" +
                        "5. Pandas\n" +
                        "6. Matplotlib\n" +
                        "7. Working with Data\n" +
                        "8. Case Study (learn to do Data Analytics on IPL and Zomato Data)");
                startActivity(intent);
            }
        });
        mlBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Introduction to Machine Learning with Python");
                intent.putExtra("b","Workshop on Introduction to Machine Learning with Python");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Basic Concept of Python Programming Language will be helpful.]");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Data Analytics\n" +
                        "2. Real Life Applications\n" +
                        "3. Setting up the tools\n" +
                        "4. Numpy Arrays\n" +
                        "5. Supervised Learning\n" +
                        "6. K nearest neighbour\n" +
                        "7. Linear Regression\n" +
                        "8. Logistic Regression\n" +
                        "9. Real Life Project- Make a Hand-Writing Classifier");
                startActivity(intent);
            }
        });
        vehicleBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Vehicle Dynamics Basics");
                intent.putExtra("b","Workshop on Vehicle Dynamics Basics");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Mechanical Engineering / Automobile] students]");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Automobile\n" +
                        "2. Vehicles Chassis Design\n" +
                        "3. Steering system\n" +
                        "4. Braking Unit\n" +
                        "5. Suspension Unit\n" +
                        "6. Electrical Unit\n" +
                        "7. Transmission\n" +
                        "8. Research\n" +
                        "9. Facbrication\n" +
                        "10. Cost Analysis");
                startActivity(intent);
            }
        });
        iotBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Introduction to IoT (Internet of Things) and Home Automation");
                intent.putExtra("b","Workshop on IoT (Internet of Things) and Home Automation");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Participant should have knowledge of Programming]\n");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to IoT concepts\n" +
                        "2. Understanding data flow in IoT\n" +
                        "3. Brief introduction to Arduino programming\n" +
                        "4. Introduction to NodeMCU\n" +
                        "5. Using NodeMCU to receive data from Internet for Automation\n" +
                        "6. Live IoT Automation Demonstration- Using a Website to automate LEDs connected to a NodeMCU\n\n" +
                        " * KIT will be provided to participants (in a Group of 4 or 5) for Practicals during Workshop.");
                startActivity(intent);
            }
        });
        hackBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Ethical Hacking");
                intent.putExtra("b","Workshop on Ethical Hacking");
                intent.putExtra("c","Suitable For:1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Networking\n" +
                        "2. Foot Printing\n" +
                        "3. Google Hacking\n" +
                        "4. Introduction to Scanning\n" +
                        "5. Windows Hacking\n" +
                        "6. Trojans & Backdoors\n" +
                        "7. Proxy\n" +
                        "8. Introduction to Denial of Service\n" +
                        "9. Social Engineering\n" +
                        "10. Steganography\n" +
                        "11. Cryptography\n" +
                        "12. Wireless Hacking\n" +
                        "13. Firewall\n" +
                        "14. Introduction to Session Hijacking\n" +
                        "15. Hacking Web Servers\n" +
                        "16. SQL Injection\n" +
                        "17. Email Hacking");
                startActivity(intent);
            }
        });
        pcbBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on PCB Design & Fabrication");
                intent.putExtra("b","Workshop on PCB Design & Fabrication");
                intent.putExtra("c","Suitable For: 1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. (ECE, EE, EEE, AEIE) students");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Familiarization with basic electronic concepts\n" +
                        "2. Introduction to Circuit Building blocks\n" +
                        "3. Overview of the Industrial PCB manufacturing processes\n" +
                        "4. Designing Schematics on CAD\n" +
                        "5. Laying out the PCB board in CAD\n" +
                        "6. Printing out the finished design\n" +
                        "7. Etching the PCB\n" +
                        "8. Assembling the PCB\n" +
                        "9. Testing the PCB\n" +
                        "10. Tips and Tricks with Home Made PCBs");
                startActivity(intent);
            }
        });htmlBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Web Desing (HTML, CSS, Bootstrap)\n");
                intent.putExtra("b","Workshop on Web Desing (HTML, CSS, Bootstrap)");
                intent.putExtra("c","Suitable For: 1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Web Design\n" +
                        "2. HTML\n" +
                        "3. CSS (Cascading Style Sheets)\n" +
                        "4. More on CSS\n" +
                        "5. Designing our Web Page\n" +
                        "6. Introduction to Bootstrap\n" +
                        "7. Designing our Web Page using Bootstrap");
                startActivity(intent);
            }
        });mcBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Motion Controlled Robot using Arduino");
                intent.putExtra("b","Workshop on Motion Controlled Robot (using Arduino)");
                intent.putExtra("c","Suitable For: 1st Yr / 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Participant should have basic knowledge of any Programming Language (at least C Language)]");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. Introduction to Arduino Microcontrollers\n" +
                        "2. Getting Used to the Arduino IDE\n" +
                        "3. Basics of Electronics\n" +
                        "4. Basics of Programming with Arduino\n" +
                        "5. Blinking an LED\n" +
                        "6. Controlling Motors with Arduino\n" +
                        "7. Basics of Robot Dynamics\n" +
                        "8. Building the Robot Structure\n" +
                        "9. Reading an Accelerometer\n" +
                        "10. Using the Accelerometer input to control the motors\n" +
                        "11. Calliberation and Tuning the Motor output to the Accelerometer input signals\n" +
                        "12. Completing the Motion Controlled Robot\n\n" +
                        " * KIT will be provided to participants (in a Group of 5) for Practicals during Workshop.");
                startActivity(intent);
            }
        });androidBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),WorkshopDetailsActivity.class);
                intent.putExtra("a","AICT Pvt Ltd presents Workshop on Android App Development.");
                intent.putExtra("b","Workshop on Android Application Development");
                intent.putExtra("c","Suitable For: 2nd Yr / 3rd Yr / 4th Yr B.Tech. / MCA / BCA students [Basic Concept of JAVA programming will be helpful.]");
                intent.putExtra("d","Topic Coverage:\n\n" +
                        "1. The Android Basics, Android Architecture\n" +
                        "2. Object Oriented Programming Principles, Basics of JAVA\n" +
                        "3. Installing Android SDK\n" +
                        "4. Understanding the Environment\n" +
                        "5. Understanding the Project Structure\n" +
                        "6. Writing the Hello World App\n" +
                        "7. UI Design in Android\n" +
                        "8. Working with Toasts\n" +
                        "9. Working with Intents\n" +
                        "10. Making a Button Counter App\n" +
                        "11. Making a Calculator App\n" +
                        "12. Making a Web Browser (if time permits)");
                startActivity(intent);
            }
        });




    }
}
