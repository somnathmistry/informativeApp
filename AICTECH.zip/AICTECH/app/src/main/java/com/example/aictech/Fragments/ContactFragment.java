package com.example.aictech.Fragments;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.aictech.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactFragment extends Fragment {
    private static final int CALL_PERMISSION_REQUEST_CODE = 1234;
    private ImageView callim, whim, fbim, instain, twtim, skypim, linkim;
    String number = "9547607753";

    public ContactFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_contact, container, false);

        callim = view.findViewById(R.id.callid);
        whim = view.findViewById(R.id.whid);
        fbim = view.findViewById(R.id.fbid);
        instain = view.findViewById(R.id.instid);
        twtim = view.findViewById(R.id.twtid);
        skypim = view.findViewById(R.id.skpid);
        linkim = view.findViewById(R.id.linkid);

        callim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + "+917001765962"));
                    getActivity().startActivity(callIntent);
                } else {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE},
                            CALL_PERMISSION_REQUEST_CODE);
                }
            }
        });

        whim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Clicked", Toast.LENGTH_SHORT).show();
                String phoneNumberWithCountryCode = "+918906352705";
                String message = "Hallo";

                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse(
                                String.format("https://api.whatsapp.com/send?phone=%s&text=%s",
                                        phoneNumberWithCountryCode, message))));
            }
        });
        fbim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/AICT248/")));
               } catch(Exception ignored) {
               }
            }
        });
        instain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/aict_pvt_ltd/")));
                } catch(Exception ignored) {
                }
            }
        });
        twtim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/AICTInnovators")));
                } catch(Exception ignored) {
                }
            }
        });
        skypim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://join.skype.com/invite/fRQQ0kneqRor")));
                } catch(Exception ignored) {
                }
            }
        });
        linkim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

}
