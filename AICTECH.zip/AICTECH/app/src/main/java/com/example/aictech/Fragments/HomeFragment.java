package com.example.aictech.Fragments;


import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aictech.Activity.CseCourseActivity;
import com.example.aictech.Activity.FinalyearProjectActivity;
import com.example.aictech.Activity.LiveClass;
import com.example.aictech.Utilities.ApiClient;
import com.example.aictech.Utilities.ApiInterface;
import com.example.aictech.Activity.CourseDetailsActivity;
import com.example.aictech.Adapters.ProjectSliderAdapter;
import com.example.aictech.Activity.RegisterActivity;
import com.example.aictech.Adapters.OfferSliderAdapter;
import com.example.aictech.Models.ProjectSlider;
import com.example.aictech.R;
import com.example.aictech.Models.TopSlider;

import java.util.List;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static android.widget.Toast.*;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private TextView viewallhometext;
    private Button register, onlineBn, demoClassBn;
    private ViewPager viewPager, viewPagerProject;
    private List<TopSlider> offerImages;
    private List<ProjectSlider> projectSliders;
    private Timer timer;
    private OfferSliderAdapter offerSliderAdapter;
    private ProjectSliderAdapter projectSliderAdapter;
    private ApiInterface projectInterface, sliderInterface;
    private Button androidhome, javahome, iothome, pythonhome, robohome, phphome, moreProject;
    public HomeFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View v = inflater.inflate(R.layout.fragment_home, container, false);
        viewPager = v.findViewById(R.id.viewPageHomeId);
        viewPagerProject = v.findViewById(R.id.viewPagerProjectId);
        register = v.findViewById(R.id.register);
        onlineBn = v.findViewById(R.id.onlinetId);
        demoClassBn = v.findViewById(R.id.freedemoId);

        androidhome = v.findViewById(R.id.androidhomeid);
        javahome = v.findViewById(R.id.javahomeid);
        iothome = v.findViewById(R.id.iothomeid);
        pythonhome = v.findViewById(R.id.pythonhomeid);
        robohome = v.findViewById(R.id.robohomeid);
        phphome = v.findViewById(R.id.phphome);
        viewallhometext = v.findViewById(R.id.viewallhometext);
        moreProject = v.findViewById(R.id.morepro);


Runnable runnableMenu = new Runnable() {
    @Override
    public void run() {

        onlineBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LiveClass.class);
                intent.putExtra("wa", "https://aictech.co.in/register/summertraining.php");
                startActivity(intent);
            }
        });
        demoClassBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LiveClass.class);
                intent.putExtra("wa", "https://aictech.co.in/Register/getDemoClass.php");
                startActivity(intent);
            }
        });

        moreProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(),FinalyearProjectActivity.class));
            }
        });


        viewallhometext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), AllCourseActivity.class));
            }
        });

        final String pythonIm = Integer.toString(R.drawable.python);
        final String androidIm = Integer.toString(R.drawable.androidvector);
        final String phpIm = Integer.toString(R.drawable.php_mysql);
        final String javaIm = Integer.toString(R.drawable.javacse);
        final String roboticsIm = Integer.toString(R.drawable.roboticscse);
        final String iotIm = Integer.toString(R.drawable.iotpro);

        androidhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String AndroidTitle = "Become an Android Expert";
                String AndroidDescription = getString(R.string.androidDes);
                String AndroidFs = getString(R.string.androdifuture);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearns = "  Core Java\n\n1.\tBasics of Android\n" +
                        "2.\tUI Widgets\n" +
                        "3.\tActivity, Intent & Fragment\n" +
                        "4.\tAndroid Menu\n" +
                        "5.\tLayout Manager\n" +
                        "6.\tAdapters\n" +
                        "7.\tView, List view and Recycler View\n" +
                        "8.\tAndroid Services\n" +
                        "9.\tData Storage and Thread\n" +
                        "10.\tSQLite and Room Database\n" +
                        "11.\tMaterial Design\n" +
                        "12.\tContent Provider and Broadcast receiver\n" +
                        "13.\tAndroid Notification\n" +
                        "14.\tMultimedia\n" +
                        "15.\tSpeech API\n" +
                        "16.\tTelephony API\n" +
                        "17.\tLocation API\n" +
                        "18.\tAnimation and Transition API\n" +
                        "19.\tDevice Connectivity\n" +
                        "20.\tSensor\n" +
                        "21.\tAndroid Web Services\n" +
                        "22.\tAndroid Google Map\n" +
                        "23.\tThird party API (facebook,google ,youtube,twitter sdks)\n" +
                        "24.\tComplete Firebase\n";
                String pros = "1.\tA full calculator App\n" +
                        "2.\tTIC TAC Game App\n" + "3.\tWeather App\n" +
                        "4.\tDoctor Appointment App\n" + "5.\tReminder\n" +
                        "6.\tCar Info App\n" + "7.\tA Music Player App\n" +
                        "8.\tWeb View App\n";
                String recS = "Basic programming knowledge should be awesome";
                Intent intent = new Intent(getActivity(), CourseDetailsActivity.class);
                intent.putExtra("im", androidIm);
                intent.putExtra("a", "ANDROID");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", AndroidTitle);
                intent.putExtra("wlearn", wlearns);
                intent.putExtra("pro", pros);
                intent.putExtra("req", recS);
                intent.putExtra("e", AndroidDescription);
                intent.putExtra("f", AndroidFs);
                startActivity(intent);
            }
        });
        javahome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String javaTitle = "Become a Java Expert";
                String javaDescription = getString(R.string.javades);
                String javaFs = getString(R.string.javafs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction\n" +
                        "2.\tOOPS\n" +
                        "3.\tPackage\n" +
                        "4.\tException Handling\n" +
                        "5.\tMultithreading\n" +
                        "6.\tApplet, AWT, Event Handling\n" +
                        "7.\tUsing NetBean, Ecllipse\n" +
                        "8.\tInput Output Streams, Serialization\n" +
                        "9.\tNetworking\n" +
                        "10.\tCollection Framework, classes & interfaces of java.util, generics\n" +
                        "11.\tIntroduction to Swing (Java Foundation Classes)\n" +
                        "13.\tRemote Method Invocation, Implementation of RMI\n" +
                        "14.\tJDBC (Java Data Base Connection), Types of Driver\n";
                String proS = "1.\tComputer Inventory system\n" +
                        "2.\tNotepad using Core Java\n" +
                        "3.\tEncryption and Decryption Text , image, and File\n" +
                        "4.\tOnline Examination System\n" +
                        "5.\tLibrary Management System\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getActivity(), CourseDetailsActivity.class);
                intent.putExtra("im", javaIm);
                intent.putExtra("a", "JAVA");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", javaTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", javaDescription);
                intent.putExtra("f", javaFs);
                startActivity(intent);

            }
        });
        iothome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String iotTitle = "Become a IOT Expert";
                String iotDescription = getString(R.string.iotdes);
                String iotFs = getString(R.string.iotfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tSoldering Methods\n" +
                        "2.\tSoldering Techniques\n" +
                        "3.\tArduino\n" +
                        "4.\tHands on session using Arduino and ESP8266\n" +
                        "5.\tDesign Digital Clock Using 7 Segment Design\n" +
                        "6.\tCrystal Oscillator\n" +
                        "7.\tIR sensor and stepper motor\n" +
                        "8.\tDigital Clock\n"+
                        "9.\tKeypad Interfacing With Arduino\n" +
                        "10.\tBluetooth Robot & Appliances, Motor driver intrefacing\n" +
                        "11.\tGSM Appliances, GPS, accelerometer\n" +
                        "13.\t\n" +
                        "14.\t\n";
                String proS = "1.\tProject design on Zero PCB Board\n" +
                        "2.\tSmart Car with Accident Prevention\n" +
                        "3.\tTemp Sensor Interfacing / MQ6 Sensor Interfacing / MQ3\n" +
                        "4.\tSensor Interfacing / Moisture Sensor / Humidity Sensor\n" +
                        "5.\tAutomatic Irrigation System\n" +
                        "6.\tWIFI, finger print & RFID interfacing\n" +
                        "7.\tElectronic Voting machine\n" +
                        "8.\tStudents attendance system\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getActivity(), CourseDetailsActivity.class);
                intent.putExtra("im", iotIm);
                intent.putExtra("a", "IOT APPLICATION DEVELOPMENT");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", iotTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", iotDescription);
                intent.putExtra("f", iotFs);
                startActivity(intent);

            }
        });
        pythonhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pythoTitle = "Become a Python Developer";
                String pythonDescription = getString(R.string.pythondes);
                String pythonFs = getString(R.string.pythonfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tLanguage Fundamentals\n" +
                        "2.\tIntroduction to Python and what is a Python\n" +
                        "3.\tWhat can we do by using Python\n" +
                        "4.\tFeatures and versions of Python\n" +
                        "5.\tDifferent languages used to develop Python\n" +
                        "6.\tInteractive mode and Script mode\n" +
                        "7.\tInterpreter vs Compiler\n" +
                        "8.\t. Scripting vs Programming Languages\n" +
                        "9.\t. Reasons to learn or work Python\n" +
                        "10.\t Python Indentation\n" +
                        "11.\t Comments and Quotations\n" +
                        "12.\tPython Identifiers and Keywords\n" +
                        "13.\tVariables\n" +
                        "14.\tAssigning values to variables in different ways\n" +
                        "15.\tPrint(), type() and id()\n" +
                        "16.\tReading data from user\n" +
                        "17.\tWorking with input function\n" +
                        "18.\tPython data types\n" +
                        "19.\tType conversions and eval()\n";

                String proS = "1.\tMessage Encode & Decode\n" +
                        "2.\tColor Game\n" +
                        "3.\tInternet Banking System\n" +
                        "4.\tPaytm Wallet\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getActivity(), CourseDetailsActivity.class);
                intent.putExtra("im", pythonIm);
                intent.putExtra("a", "PYTHON");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", pythoTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", pythonDescription);
                intent.putExtra("f", pythonFs);
                startActivity(intent);

            }
        });
        robohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roboTitle = "Become a Robotics Expert";
                String roboDescription = getString(R.string.robodes);
                String roboFs = getString(R.string.robofs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction to ROBOTICS\n" +
                        "2.\tIntroduction to Electronics\n" +
                        "3.\tIntroduction to Autonomous Robots\n" +
                        "4.\tL293DC\n" +
                        "5.\tIntroduction to Embedded system\n" ;
                String proS = "Contact Now";
                String recS = "Basic programming knowledge should be awesome";
                Intent intent = new Intent(getActivity(), CourseDetailsActivity.class);
                intent.putExtra("im", roboticsIm);
                intent.putExtra("a", "ROBOTICS");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", roboTitle);
                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", roboDescription);
                intent.putExtra("f", roboFs);
                startActivity(intent);

            }
        });
        phphome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String netTitle = "Become a Php Developer";
                String netDescription = getString(R.string.phpdes);
                String netFs = getString(R.string.phpfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction of Php\n" +
                        "2.\tHandling HTML from with Php\n" +
                        "3.\tDecisions and loop\n" +
                        "4.\tString and Array\n" +
                        "5.\tWorking with File and Directories\n" +
                        "6.\tState management and String matching with regular expression\n" +
                        "7.\tGenerating Images with PHP\n" +
                        "8.\tIntroduction to RDBMS Connection with MySql Database\n" +
                        "9.\tModels\n" +
                        "10.\tHTML\n" +
                        "11.\tCSS\n" +
                        "13.\tJAVASCRIPT\n";

                String proS = "1.\tStudent management system\n" +
                        "2.\tGmail System\n" +
                        "3.\tShopping cart with internet banking\n" +
                        "4.\tBlood bank management\n" +
                        "5.\tLibery management\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getActivity(), CourseDetailsActivity.class);
                intent.putExtra("im", phpIm);
                intent.putExtra("a", "PHP WITH MYSQL");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", netTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", netDescription);
                intent.putExtra("f", netFs);
                startActivity(intent);

            }
        });
    }
};
        try {
            Thread threadMenu = new Thread(runnableMenu);
            threadMenu.start();
        }catch (Exception e){
            e.printStackTrace();
        }

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), RegisterActivity.class);
                startActivity(intent);
            }
        });

        return v;

    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
//        myRecycler.setLayoutManager(linearLayoutManager);
//        myRecycler.setHasFixedSize(true);
//
//
//        getImagesForTopCategory();
        getImagesForSlider();
        getImagesforProjectSlider();

    }

    public void getImagesforProjectSlider() {
        projectInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<List<ProjectSlider>> proCall = projectInterface.getProjectSlider();
        proCall.enqueue(new Callback<List<ProjectSlider>>() {
            @Override
            public void onResponse(Call<List<ProjectSlider>> call, Response<List<ProjectSlider>> response) {
                if (response.isSuccessful()){
                    projectSliders = response.body();
                    projectSliderAdapter = new ProjectSliderAdapter(projectSliders,getActivity());
                    viewPagerProject.setAdapter(projectSliderAdapter);
                    createProSlideShow();
                    //Toast.makeText(getContext(), "Project Response"+response.body(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<ProjectSlider>> call, Throwable t) {
                try {
                    makeText(getContext(), "       Slow INTERNET\nPlease Relaunch the App", LENGTH_LONG).show();
                }catch (Exception e){

                }
            }
        });
    }

    public void getImagesForSlider() {

        sliderInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<List<TopSlider>> query = sliderInterface.getSlider();
        query.enqueue(new Callback<List<TopSlider>>() {
            @Override
            public void onResponse(Call<List<TopSlider>> call, Response<List<TopSlider>> response) {
                if (response.isSuccessful()) {

                    offerImages = response.body();
                    offerSliderAdapter = new OfferSliderAdapter(offerImages, getActivity());
                    viewPager.setAdapter(offerSliderAdapter);
                    createSlideShow();
                    //Toast.makeText(getContext(), "Response Success"+response.body(), Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onFailure(Call<List<TopSlider>> call, Throwable t) {
                try {
                    Toast.makeText(getContext(), "Slow Internet\n please relaunch"+t.getMessage(), Toast.LENGTH_LONG).show();
                }
                catch (Exception e){
                    //Toast.makeText(getContext(), "Slow Internet", LENGTH_SHORT).show();
                }


            }
        });
}

    private void createSlideShow() {
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                int currentPosition = viewPager.getCurrentItem();
                if (currentPosition == offerImages.size() - 1) {
                    currentPosition = -1;
                }
                viewPager.setCurrentItem(++currentPosition, true);
            }
        };
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 1000, 2000);
    }





    private void createProSlideShow() {
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                int currentPosition = viewPagerProject.getCurrentItem();
                if (currentPosition == projectSliders.size() - 1) {
                    currentPosition = -1;
                }
                viewPagerProject.setCurrentItem(++currentPosition, true);
            }
        };
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 1000, 2000);
    }
}
