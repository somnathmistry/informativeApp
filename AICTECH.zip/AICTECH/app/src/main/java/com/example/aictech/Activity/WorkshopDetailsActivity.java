package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.aictech.R;

public class WorkshopDetailsActivity extends AppCompatActivity {

    TextView bestTx, introTx, branchTx, topicTx;
    Button buyproject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workshop_details);

        bestTx = findViewById(R.id.best);
        introTx = findViewById(R.id.intro);
        branchTx = findViewById(R.id.branchId);
        topicTx = findViewById(R.id.topicId);
        buyproject = findViewById(R.id.buyproject);
        buyproject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),RegisterActivity.class));
            }
        });

        String best = getIntent().getStringExtra("a");
        String intro = getIntent().getStringExtra("b");
        String branch = getIntent().getStringExtra("c");
        String topic = getIntent().getStringExtra("d");
        bestTx.setText(best);
        introTx.setText(intro);
        branchTx.setText(branch);
        topicTx.setText(topic);

    }
}
