package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.aictech.R;

public class MeCourseActivity extends AppCompatActivity {
    private Button stadproB, catiaB, inventorB, solidB, autocadB, regBot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me_course);

        stadproB = findViewById(R.id.stadBn);
        catiaB = findViewById(R.id.catiaBn);
        inventorB = findViewById(R.id.inventorBn);
        solidB = findViewById(R.id.solidBn);
        autocadB = findViewById(R.id.autocadBn);
        regBot = findViewById(R.id.meregbot);

        final String stadIm = Integer.toString(R.drawable.staad);
        final String catiaIm = Integer.toString(R.drawable.catia);
        final String inventorIm = Integer.toString(R.drawable.inventor);
        final String solidIm = Integer.toString(R.drawable.solidwork);
        final String autocadIm = Integer.toString(R.drawable.autocad);

        regBot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
            }
        });

        stadproB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stadTitle = getString(R.string.staadtitle);
                String stadDescription = getString(R.string.staddes);
                String stadFs = getString(R.string.staadfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction to STAAD.Pro\n" +
                        "2.\tModel editing tools\n" +
                        "3.\tCreating Models by using structure wizard\n" +
                        "4.\tIntroduction to analysis\n" +
                        "5.\tSTAAD.BEAVA\n" ;
                String proS = "1.\tWater Tank. Water tanks are storage containers of water; these tanks usually stores water for human consumption\n" +
                        "2.\tCommunication tower design\n" ;
                String recS = "Basic programming & hardware knowledge and hardware should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", stadIm);
                intent.putExtra("a", "STAAD.PRO");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", stadTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", stadDescription);
                intent.putExtra("f", stadFs);
                startActivity(intent);
            }
        });
        catiaB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String catiaTitle = getString(R.string.catiatitle);
                String catiaDescription = getString(R.string.catiades);
                String catiaFs = getString(R.string.catiafs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction to CATIA\n" +
                        "2.\tDrawing sketches in the sketcher workbench\n" +
                        "3.\tConstraining Sketches & creating Base Features\n" +
                        "4.\tCreating dress_up and hole features\n" +
                        "5.\tTransformation Features\n" +
                        "6.\tAdvanced modeling\n" +
                        "7.\tAssembly Modeling\n";
                String proS = "1.\tPart Design using CATIA\n" +
                        "2.\tSheet Metal and Surface Modeling\n" +
                        "3.\tMechanism Design using\n" ;
                String recS = "Basic design knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", catiaIm);
                intent.putExtra("a", "CATIA");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", catiaTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", catiaDescription);
                intent.putExtra("f", catiaFs);
                startActivity(intent);
            }
        });
        inventorB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inTitle = getString(R.string.inventortitle);
                String inDescription = getString(R.string.inventordes);
                String inFs = getString(R.string.inventorfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tDiscovering Drafting fundamentals\n" +
                        "2.\tResidential Design\n" +
                        "3.\tDrafting views and annotations\n" +
                        "4.\tSpeciality Drafting and design\n";
                String proS = "1.\tAutomoblox Car\n" +
                        "2.\tGeodesic Dome Jungle Gym\n" ;
                String recS = "Basic knowledge in mechanical engineering or design";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", inventorIm);
                intent.putExtra("a", "IOT APPLICATION DEVELOPMENT");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", inTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", inDescription);
                intent.putExtra("f", inFs);
                startActivity(intent);
            }
        });
        solidB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String solidTitle = getString(R.string.solidtitle);
                String solidDescription = getString(R.string.soliddes);
                String solidFs = getString(R.string.solidfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tSolidWorks graphical user interface\n" +
                        "2.\tSketcher\n" +
                        "3.\tPart Modeling\n" +
                        "4.\tSurface Modeling\n" +
                        "5.\tDrafting\n" +
                        "6.\tSheet Metal\n" ;
                String proS = "Contact now";
                String recS = "Basic knowledge in mechanical engineering or design";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", solidIm);
                intent.putExtra("a", "SOLID WORKS");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", solidTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", solidDescription);
                intent.putExtra("f", solidFs);
                startActivity(intent);
            }
        });
        autocadB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String autoTitle = getString(R.string.autotitle);
                String autoDescription = getString(R.string.autodes);
                String autoFs = getString(R.string.autofs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tEngineering Drawing\n" +
                        "2.\tComputer Fundamentals\n" +
                        "3.\tAutocad using drawing\n" +
                        "4.\tIsometric drawing\n" ;
                String proS = "1.\tAutocad Inventor 3D design\n" +
                        "2.\tCreate architectural model\n" +
                        "3.\t3D character animation\n" +
                        "4.\tIndustrial area 3D desing\n";
                String recS = "Basic knowledge in computer fundamentals and engineering or design";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", autocadIm);
                intent.putExtra("a", "AUTOCAD (2D & 3D)");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", autoTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", autoDescription);
                intent.putExtra("f", autoFs);
                startActivity(intent);
            }
        });
    }
}
