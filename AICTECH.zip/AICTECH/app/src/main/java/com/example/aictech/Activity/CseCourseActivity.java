package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.aictech.R;

public class CseCourseActivity extends AppCompatActivity {
    private Button pythoncard, androidcard, netcard, phpcard, javacard, bigdatacard,
            webdevcard, meancard, roboticscard, canddatacard, dscard, automationcard, maualcard, mlcard;
    private Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cse_course);
        pythoncard = findViewById(R.id.cdIdpython);
        androidcard = findViewById(R.id.cdIdandroid);
        netcard = findViewById(R.id.cdIdnet);
        phpcard = findViewById(R.id.cdIdphp);
        javacard = findViewById(R.id.cdIdjava);
        bigdatacard = findViewById(R.id.cdIddata);
        webdevcard = findViewById(R.id.cdIdweb);
        meancard = findViewById(R.id.cdIdmeanstak);
        roboticscard = findViewById(R.id.cdIdrobotics);
        canddatacard = findViewById(R.id.cdIdcanddatastruct);
        dscard = findViewById(R.id.cdIddataandalgo);
        automationcard = findViewById(R.id.cdIdautomation);
        maualcard = findViewById(R.id.cdId1manual);
        mlcard = findViewById(R.id.cdIdml);

        final String pythonIm = Integer.toString(R.drawable.python);
        final String androidIm = Integer.toString(R.drawable.androidvector);
        final String phpIm = Integer.toString(R.drawable.php_mysql);
        final String javaIm = Integer.toString(R.drawable.javacse);
        final String roboticsIm = Integer.toString(R.drawable.roboticscse);
        final String bigdataIm = Integer.toString(R.drawable.bigdatacse);
        final String webIm = Integer.toString(R.drawable.webdesign);
        final String meanIm = Integer.toString(R.drawable.meanstackcse);
        final String netIm = Integer.toString(R.drawable.netcse);
        final String canddIm = Integer.toString(R.drawable.datacse);
        final String dsIm = Integer.toString(R.drawable.dataalgocse);
        final String autoIm = Integer.toString(R.drawable.software_automation);
        final String maualIm = Integer.toString(R.drawable.maual_testing);
        final String mlIm = Integer.toString(R.drawable.mlcse);
        register = findViewById(R.id.csereg);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
            }
        });

        pythoncard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pythoTitle = "Become a Python Developer";
                String pythonDescription = getString(R.string.pythondes);
                String pythonFs = getString(R.string.pythonfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tLanguage Fundamentals\n" +
                        "2.\tIntroduction to Python and what is a Python\n" +
                        "3.\tWhat can we do by using Python\n" +
                        "4.\tFeatures and versions of Python\n" +
                        "5.\tDifferent languages used to develop Python\n" +
                        "6.\tInteractive mode and Script mode\n" +
                        "7.\tInterpreter vs Compiler\n" +
                        "8.\t. Scripting vs Programming Languages\n" +
                        "9.\t. Reasons to learn or work Python\n" +
                        "10.\t Python Indentation\n" +
                        "11.\t Comments and Quotations\n" +
                        "12.\tPython Identifiers and Keywords\n" +
                        "13.\tVariables\n" +
                        "14.\tAssigning values to variables in different ways\n" +
                        "15.\tPrint(), type() and id()\n" +
                        "16.\tReading data from user\n" +
                        "17.\tWorking with input function\n" +
                        "18.\tPython data types\n" +
                        "19.\tType conversions and eval()\n";

                String proS = "1.\tMessage Encode & Decode\n" +
                        "2.\tColor Game\n" +
                        "3.\tInternet Banking System\n" +
                        "4.\tPaytm Wallet\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", pythonIm);
                intent.putExtra("a", "PYTHON");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", pythoTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", pythonDescription);
                intent.putExtra("f", pythonFs);
                startActivity(intent);
            }
        });
        androidcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String AndroidTitle = "Become an Android Expert";
                String AndroidDescription = getString(R.string.androidDes);
                String AndroidFs = getString(R.string.androdifuture);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearns = "  Core Java\n\n1.\tBasics of Android\n" +
                        "2.\tUI Widgets\n" +
                        "3.\tActivity, Intent & Fragment\n" +
                        "4.\tAndroid Menu\n" +
                        "5.\tLayout Manager\n" +
                        "6.\tAdapters\n" +
                        "7.\tView, List view and Recycler View\n" +
                        "8.\tAndroid Services\n" +
                        "9.\tData Storage and Thread\n" +
                        "10.\tSQLite and Room Database\n" +
                        "11.\tMaterial Design\n" +
                        "12.\tContent Provider and Broadcast receiver\n" +
                        "13.\tAndroid Notification\n" +
                        "14.\tMultimedia\n" +
                        "15.\tSpeech API\n" +
                        "16.\tTelephony API\n" +
                        "17.\tLocation API\n" +
                        "18.\tAnimation and Transition API\n" +
                        "19.\tDevice Connectivity\n" +
                        "20.\tSensor\n" +
                        "21.\tAndroid Web Services\n" +
                        "22.\tAndroid Google Map\n" +
                        "23.\tThird party API (facebook,google ,youtube,twitter sdks)\n" +
                        "24.\tComplete Firebase\n";
                String pros = "1.\tA full calculator App\n" +
                        "2.\tTIC TAC Game App\n" + "3.\tWeather App\n" +
                        "4.\tDoctor Appointment App\n" + "5.\tReminder\n" +
                        "6.\tCar Info App\n" + "7.\tA Music Player App\n" +
                        "8.\tWeb View App\n";
                String recS = "Basic programming knowledge should be awesome";
                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", androidIm);
                intent.putExtra("a", "ANDROID");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", AndroidTitle);

                intent.putExtra("wlearn", wlearns);
                intent.putExtra("pro", pros);
                intent.putExtra("req", recS);
                intent.putExtra("e", AndroidDescription);
                intent.putExtra("f", AndroidFs);
                startActivity(intent);
            }
        });
        netcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String netTitle = "Become a dot.Net Developer";
                String netDescription = getString(R.string.netdes);
                String netFs = getString(R.string.netfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tFundamentals\n" +
                        "2.\t.Net Framework\n" +
                        "3.\tControls\n" +
                        "4.\tDatabase Connectivity \n";
                String proS = "1.\tWebsite\n" +
                        "2.\tManagement System\n" +
                        "3.\tWebsite with latest .Net Framework\n" +
                        "4.\tBooking Website\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", netIm);
                intent.putExtra("a", ".NET");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", netTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", netDescription);
                intent.putExtra("f", netFs);
                startActivity(intent);
            }
        });
        phpcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String netTitle = "Become a Php Developer";
                String netDescription = getString(R.string.phpdes);
                String netFs = getString(R.string.phpfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction of Php\n" +
                        "2.\tHandling HTML from with Php\n" +
                        "3.\tDecisions and loop\n" +
                        "4.\tString and Array\n" +
                        "5.\tWorking with File and Directories\n" +
                        "6.\tState management and String matching with regular expression\n" +
                        "7.\tGenerating Images with PHP\n" +
                        "8.\tIntroduction to RDBMS Connection with MySql Database\n" +
                        "9.\tModels\n" +
                        "10.\tHTML\n" +
                        "11.\tCSS\n" +
                        "13.\tJAVASCRIPT\n";

                String proS = "1.\tStudent management system\n" +
                        "2.\tGmail System\n" +
                        "3.\tShopping cart with internet banking\n" +
                        "4.\tBlood bank management\n" +
                        "5.\tLibery management\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", phpIm);
                intent.putExtra("a", "PHP WITH MYSQL");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", netTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", netDescription);
                intent.putExtra("f", netFs);
                startActivity(intent);
            }
        });
        javacard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String javaTitle = "Become a Java Expert";
                String javaDescription = getString(R.string.javades);
                String javaFs = getString(R.string.javafs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction\n" +
                        "2.\tOOPS\n" +
                        "3.\tPackage\n" +
                        "4.\tException Handling\n" +
                        "5.\tMultithreading\n" +
                        "6.\tApplet, AWT, Event Handling\n" +
                        "7.\tUsing NetBean, Ecllipse\n" +
                        "8.\tInput Output Streams, Serialization\n" +
                        "9.\tNetworking\n" +
                        "10.\tCollection Framework, classes & interfaces of java.util, generics\n" +
                        "11.\tIntroduction to Swing (Java Foundation Classes)\n" +
                        "13.\tRemote Method Invocation, Implementation of RMI\n" +
                        "14.\tJDBC (Java Data Base Connection), Types of Driver\n";
                String proS = "1.\tComputer Inventory system\n" +
                        "2.\tNotepad using Core Java\n" +
                        "3.\tEncryption and Decryption Text , image, and File\n" +
                        "4.\tOnline Examination System\n" +
                        "5.\tLibrary Management System\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", javaIm);
                intent.putExtra("a", "JAVA");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", javaTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", javaDescription);
                intent.putExtra("f", javaFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        bigdatacard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bdTitle = "Become a BigData Expert";
                String bdDescription = getString(R.string.bddes);
                String bdFs = getString(R.string.bdfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tSoldering Methods\n" +
                        "2.\tSoldering Techniques\n" +
                        "3.\tProgramming & Arduino\n" +
                        "4.\tHands on session using Arduino and ESP8266\n" +
                        "5.\tDesign Digital Clock Using 7 Segment Design\n" +
                        "6.\tCrystal oscillators.\n" +
                        "7.\tIR sensor & Stepper Motor\n" +
                        "8.\tReal Time-Based Digital Clock (I2c Protocol)\n" +
                        "9.\tKeypad Interfacing With Arduino\n" +
                        "10.\tBluetooth Based Appliances Control & Motor Driver Interfacing\n" +
                        "11.\tSmart Car with Accident Prevention \n" +
                        "12.\tTemp Sensor Interfacing/MQ6 Sensor Interfacing/MQ3 Sensor Interfacing/Moisture Sensor/Humidity Sensor\n" +
                        "13.\tAutomatic Irrigation System \n" +
                        "14.\tWIFI Based Home Automation\n" +
                        "15.\tElectronic Voting Machine, Student Attendance System \n" +
                        "16.\tCompetition, Doubts & Practical Session\n" +
                        "17.\tCertificate Distribution Cum Farewell Ceremony\n";
                String proS = "1.\tAutomatic wireless health Monitoring System.\n" +
                        "2.\tLine following robotic vehicle.\n" +
                        "3.\tTelevision Remote operated domestic/motor/industrial appliances control.\n" +
                        "4.\tPassword based circuit breaker.\n" +
                        "5.\tStreet light that glow on detecting vehicles movement.\n" +
                        "6.\tGsm based monthly energy meter billing via sms.\n" +
                        "7.\tSecurity system with user changeable password.\n" +
                        "8.\tDTMF using appliances control.\n" +
                        "9.\tAutomatic solar tracker.\n" +
                        "10.\tWireless electronics notice board using gsm.\n" +
                        "11.\tEletronics Voting Machine.\n" +
                        "12.\tRF Based home automation system.\n" +
                        "13.\tControling and monitoring of green house agriculture system.\n" +
                        "14.\tBidirectional visitor counter using 8051.\n" +
                        "15.\tAutomatic temperature controlled speed regulation of induction motor.\n" +
                        "16.\tCNC machine.\n" +
                        "17.\tBiometric voting machine.\n" +
                        "18.\tAutomatic street light controller circuit using relay and LDR.\n" +
                        "19.\tSmart blind stick.\n" +
                        "20.\tBuck chopper.\n" +
                        "21.\tBust chopper.\n" +
                        "22.\tINDUSTRIAL appliances control using SCADA.\n" +
                        "23.\tHeart beat monitoring system.\n" +
                        "24.\tGesture control robot.\n" +
                        "25.\tAutomatic Water level indicator with motor control and pump operation.\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", bigdataIm);
                intent.putExtra("a", "BIG DATA WITH INDUSTRIAL PROJECTS");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", bdTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", bdDescription);
                intent.putExtra("f", bdFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        webdevcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String webTitle = "Become a Full Stack Web Developer";
                String webDescription = getString(R.string.webdes);
                String webFs = getString(R.string.webfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tHTML (in details)\n" +
                        "2.\tCSS (in details)\n" +
                        "3.\tJavaScript (in details)\n" +
                        "4.\tOOPs\n" +
                        "5.\tDesign Patterns\n" +
                        "6.\tObject Oriented Design\n" +
                        "7.\tJSON\n" +
                        "8.\tDOM\n" +
                        "9.\tAJAX\n" +
                        "10.\tNode Core\n" +
                        "11.\tNode Modules\n" +
                        "13.\tFile System\n" +
                        "14.\tDebugger\n" +
                        "15.\tAutomation and Deployment\n" +
                        "16.\tIntroduction to Web sockets\n" +
                        "17.\tWeb socket URIs\n" +
                        "18.\tWeb socket APIs\n" +
                        "19.\tOpening Handshake\n" +
                        "20.\tData Framing\n" +
                        "21.\tSending and Receiving Data\n" +
                        "22.\tClosing the Connections\n" +
                        "23.\tWeb socket Security\n";
                String proS = "1.\tContent Management System for a blog\n" +
                        "2.\tMulti-client website offering client services\n" +
                        "3.\te-commerce website for automotive parts\n" +
                        "4.\tFood delivery application\n" +
                        "5.\tGrocery delivery application\n" +
                        "6.\te-commerce portal for used furniture sales\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", webIm);
                intent.putExtra("a", "WEB DESIGNING & DEVELOPMENT");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", webTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", webDescription);
                intent.putExtra("f", webFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        meancard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String meanTitle = "Become a Mean Stack Developer";
                String meanDescription = getString(R.string.meantitle);
                String meanFs = getString(R.string.meanfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tNode.Js\n" +
                        "2.\tAngular.Js\n" +
                        "3.\tExpress.Js\n" +
                        "4.\tMongoDB\n" ;
                String proS = "1.\tLogin Authentication Frontend\n" +
                        "2.\tLogin Authentication Backend\n" +
                        "3.\tE-commerce Application Frontend\n" +
                        "4.\tE-commerce Application Backend\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", meanIm);
                intent.putExtra("a", "MEAN STACK");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", meanTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", meanDescription);
                intent.putExtra("f", meanFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        roboticscard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roboTitle = "Become a Robotics Expert";
                String roboDescription = getString(R.string.robodes);
                String roboFs = getString(R.string.robofs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction to ROBOTICS\n" +
                        "2.\tIntroduction to Electronics\n" +
                        "3.\tIntroduction to Autonomous Robots\n" +
                        "4.\tL293DC\n" +
                        "5.\tIntroduction to Embedded system\n" ;
                String proS = "Contact Now";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", roboticsIm);
                intent.putExtra("a", "ROBOTICS");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", roboTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", roboDescription);
                intent.putExtra("f", roboFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        canddatacard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dncTitle = "Become a DataBase Expert";
                String dncDescription = getString(R.string.dncdes);
                String dncnFs = getString(R.string.dncfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction to C Language\n" +
                        "2.\tBranching and Looping\n" +
                        "3.\tFunction, Arrays and String\n" +
                        "4.\tstructures and File management\n" +
                        "5.\tData Structure\n" ;
                String proS = "1.\tbank management system\n" +
                        "2.\tUniversity Management System\n" +
                        "3.\tCustomer Billing system \n" +
                        "4.\tCricket Score Sheet\n" +
                        "5.\tSchool Management system\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", canddIm);
                intent.putExtra("a", "C & DATA STRUCTURE");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", dncTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", dncDescription);
                intent.putExtra("f", dncnFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        dscard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dsTitle = "Learn Data and become an Expert";
                String dsDescription = getString(R.string.dstitle);
                String dsFs = getString(R.string.dsfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tData Structure Basics\n" +
                        "2.\tGraph and trees\n" +
                        "3.\tSearching and Sorting\n" +
                        "4.\tElementary Algorithms\n" +
                        "5.\tGreedy Method\n" +
                        "6.\tBacktracking Strategy\n" ;

                String proS = "1.\tBinary heap\n" +
                        "2.\tCuckoo hash table\n" +
                        "3.\tDouble hash table\n" +
                        "4.\tDynamic double hash table\n" +
                        "5.\tDynamic linear hash table\n" +
                        "6.\tDynamic min heap\n" +
                        "7.\tHeapify\n" +
                        "8.\tLinear replacement hash table\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", dsIm);
                intent.putExtra("a", "DATA STRUCTURES WITH ALGORITHM");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", dsTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", dsDescription);
                intent.putExtra("f", dsFs);
                startActivity(intent);
//                PHP TRAINING IN DURGAPUR
            }
        });
        automationcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amTitle = "Become a Software Tester";
                String amDescription = getString(R.string.amdes);
                String amFs = getString(R.string.amfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\t\n" +
                        "2.\tIntroduction to Automation testing\n" +
                        "3.\tIntroduction to Selenium\n" +
                        "4.\tIntroduction to Java\n" +
                        "5.\tIntroduction to Selenium IDE and Frameworks\n" +
                        "6.\tDatabase Testing\n" +
                        "7.\tSelenium Grid\n" +
                        "8.\tPage Object Model\n";
                String proS = "Contact Now";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", autoIm);
                intent.putExtra("a", "AUTOMATION TESTING WITH SELENIUM");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", amTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", amDescription);
                intent.putExtra("f", amFs);
                startActivity(intent);
            }
        });
        maualcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String manualTitle = "Become a Software Tester";
                String manualDescription = getString(R.string.manualdes);
                String manualFs = getString(R.string.manualfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tSoftware Testing Introduction\n" +
                        "2.\tSoftware Development lifecycle\n" +
                        "3.\tSoftware Testing Methodologies\n" +
                        "4.\tTest case Design Techniques\n" +
                        "5.\tLevels of Testing\n" +
                        "6.\tSoftware Testing Lifecycle\n" ;
                String proS = "Contact Now";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", maualIm);
                intent.putExtra("a", "MANIUAL TESTNG");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", manualTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", manualDescription);
                intent.putExtra("f", manualFs);
                startActivity(intent);
            }
        });
        mlcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mlTitle = "Learn ML and become an Expert";
                String mlDescription = getString(R.string.mlds);
                String mlFs = getString(R.string.mlfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntrduction  to Machine Learning\n" +
                        "2.\tRegression\n" +
                        "3.\tClassification\n" +
                        "4.\tUnsupervised learning\n" +
                        "5.\tRecommender systems\n" ;
                String proS = "1.\tLearn about Supervised Machine Learning Algorithms\n" +
                        "2.\tSocial Media Sentiment Analysis\n" +
                        "3.\tStock Prices Predictor\n" +
                        "4.\tHuman Activity Recognition using Smartphone Dataset\n" ;
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", mlIm);
                intent.putExtra("a", "MACHINE LEARNING WITH PYTHON");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact Now");
                intent.putExtra("d", mlTitle);
                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", mlDescription);
                intent.putExtra("f", mlFs);
                startActivity(intent);
            }
        });
    }
}
