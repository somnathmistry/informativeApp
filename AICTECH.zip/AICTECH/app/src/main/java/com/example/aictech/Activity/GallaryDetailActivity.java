package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.aictech.R;

public class GallaryDetailActivity extends AppCompatActivity {

   private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallary_detail);
        imageView = findViewById(R.id.imagedetail);

        Intent intent = getIntent();
        String s = intent.getStringExtra("img");
        Glide.with(this)
                .load(s)
                .into(imageView);
    }
}
