package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;

import com.example.aictech.R;

public class RegisterActivity extends AppCompatActivity {
    private WebView regWeb;
    private String baseurl = "https://aictech.co.in/register/";
    private String insta = "https://www.instamojo.com/@AICT_Pvt_Ltd#";
    ProgressBar progressBar;
    Button regUpiPay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        regUpiPay = findViewById(R.id.regupid);
        regWeb = findViewById(R.id.registerwebId);
        progressBar = findViewById(R.id.spin_kit);
        progressBar.setVisibility(View.VISIBLE);

        regUpiPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegPaymentActivity.class));
            }
        });


        regWeb.loadUrl(baseurl);
        regUpiPay.setVisibility(View.GONE);

        regWeb.clearCache(true);
        regWeb.getSettings().setJavaScriptEnabled(true);
        regWeb.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                regWeb.loadUrl("file:///android_asset/e.html");

            }

            /**
             * @param view
             * @param url
             * @deprecated
             */
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                view.loadUrl(insta);
                String instaweb = regWeb.getUrl();

                if (instaweb.equals(insta)) {
                    regUpiPay.setVisibility(View.VISIBLE);
                }

                return false;

            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);

            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);

            }
        });
    }

    @Override
    public void onBackPressed() {
        if (regWeb.canGoBack()) {
            regWeb.goBack();
            regUpiPay.setVisibility(View.GONE);
        } else {
            //startActivity(new Intent(getApplicationContext(),EtcCourseActivity.class));
            super.onBackPressed();
        }

    }
}
