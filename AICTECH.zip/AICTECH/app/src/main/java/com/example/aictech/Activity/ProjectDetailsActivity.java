package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.aictech.R;

public class ProjectDetailsActivity extends AppCompatActivity {
    private TextView projectname, projectdes, buyprojects;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_details);

        projectname = findViewById(R.id.textdemo);
        projectdes = findViewById(R.id.prodetailsddemo);
        buyprojects = findViewById(R.id.buyproject);

        String pn = getIntent().getStringExtra("a");
        String pd = getIntent().getStringExtra("b");
        projectname.setText(pn);
        projectdes.setText(pd);

        buyprojects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Payment.class);
                startActivity(intent);

            }
        });
    }
}
