package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.example.aictech.R;

public class LiveClass extends AppCompatActivity {
    private WebView regWeb;
    private String baseurl = "https://aictech.co.in/Register/liveClass.php";

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_class);
        regWeb = findViewById(R.id.livewebId);
        progressBar = findViewById(R.id.spin_kit);
        progressBar.setVisibility(View.VISIBLE);

        String web = getIntent().getStringExtra("wa");
        regWeb.loadUrl(web);

        regWeb.clearCache(true);
        regWeb.getSettings().setJavaScriptEnabled(true);
        regWeb.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                regWeb.loadUrl("file:///android_asset/e.html");


            }

            /**
             * @param view
             * @param url
             * @deprecated
             */
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);

                return false;

            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if(regWeb.canGoBack()){
            regWeb.goBack();
        }
        else {
            //startActivity(new Intent(getApplicationContext(),MainActivity.class));
            super.onBackPressed();}

    }

}
