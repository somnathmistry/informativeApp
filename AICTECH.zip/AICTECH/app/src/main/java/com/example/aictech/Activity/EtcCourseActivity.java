package com.example.aictech.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.aictech.R;

public class EtcCourseActivity extends AppCompatActivity {
    private Button plcBn, pbcBn, iotBn, embadedBn, regBot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etc_course);
        plcBn = findViewById(R.id.plcBn);
        pbcBn = findViewById(R.id.cdIdandroid);
        iotBn = findViewById(R.id.cdIdnet);
        embadedBn = findViewById(R.id.cdIdphp);
        regBot = findViewById(R.id.etcregBot);

        final String plcIm = Integer.toString(R.drawable.scada);
        final String pbcIm = Integer.toString(R.drawable.pcb);
        final String iotIm = Integer.toString(R.drawable.iot_application);
        final String emIm = Integer.toString(R.drawable.embaded);

        regBot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
            }
        });

        plcBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String plcTitle = "Become a PLC Scada Expert";
                String plcDescription = getString(R.string.plcdes);
                String plcFs = getString(R.string.plcfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tPLC Fundamentals\n" +
                        "2.\tProgramming Instructions\n" +
                        "3.\tSCADA system application\n" +
                        "4.\tSCADA Screen\n" ;
                String proS = "1.\tSCADA system application on Oil GAS\n" +
                        "2.\tSCADA system application Solar on Power Plant\n" +
                        "3.\tSCADA system application Steel on Plant\n" +
                        "4.\tCreating & Editing graphic display with animation\n" +
                        "5.\tCreating & Accessing Real-time\n" ;
                String recS = "Basic programming knowledge of PLC Programming, Automation and SCADA";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", plcIm);
                intent.putExtra("a", "PLC and SCADA");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", plcTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", plcDescription);
                intent.putExtra("f", plcFs);
                startActivity(intent);
            }
        });
        pbcBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pbcTitle = "Become a PCB & Circuit Designing Expert";
                String pbcDescription = getString(R.string.pbcdes);
                String pbcFs = getString(R.string.pbcfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tIntroduction to Electronic design automation\n" +
                        "2.\tComponents introduction & there categories\n" +
                        "3.\tIntroduction to Development tools\n" +
                        "4.\tDetailed description and practicals of PCB designing\n" +
                        "5.\tLab practice and designing concepts\n";
                String proS = "1.\tCrystal Tester. Crystal is used as an oscillator, to generate a high frequency\n" +
                        "2.\tBattery Voltage Monitor\n" +
                        "3.\tLED Indicator Light\n" +
                        "4.\tElectronic Thermometer\n" +
                        "5.\tElectronic Motor Controller\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", pbcIm);
                intent.putExtra("a", "PCB AND CIRCUIT DESIGNING");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", pbcTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", pbcDescription);
                intent.putExtra("f", pbcFs);
                startActivity(intent);
            }
        });
        iotBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String iotTitle = "Become a IOT Expert";
                String iotDescription = getString(R.string.iotdes);
                String iotFs = getString(R.string.iotfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tSoldering Methods\n" +
                        "2.\tSoldering Techniques\n" +
                        "3.\tArduino\n" +
                        "4.\tHands on session using Arduino and ESP8266\n" +
                        "5.\tDesign Digital Clock Using 7 Segment Design\n" +
                        "6.\tCrystal Oscillator\n" +
                        "7.\tIR sensor and stepper motor\n" +
                        "8.\tDigital Clock\n"+
                        "9.\tKeypad Interfacing With Arduino\n" +
                        "10.\tBluetooth Robot & Appliances, Motor driver intrefacing\n" +
                        "11.\tGSM Appliances, GPS, accelerometer\n" +
                        "13.\t\n" +
                        "14.\t\n";
                String proS = "1.\tProject design on Zero PCB Board\n" +
                        "2.\tSmart Car with Accident Prevention\n" +
                        "3.\tTemp Sensor Interfacing / MQ6 Sensor Interfacing / MQ3\n" +
                        "4.\tSensor Interfacing / Moisture Sensor / Humidity Sensor\n" +
                        "5.\tAutomatic Irrigation System\n" +
                        "6.\tWIFI, finger print & RFID interfacing\n" +
                        "7.\tElectronic Voting machine\n" +
                        "8.\tStudents attendance system\n";
                String recS = "Basic programming knowledge should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", iotIm);
                intent.putExtra("a", "IOT APPLICATION DEVELOPMENT");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", iotTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", iotDescription);
                intent.putExtra("f", iotFs);
                startActivity(intent);
            }
        });
        embadedBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emTitle = "Do Complete Embedded System";
                String emDescription = getString(R.string.emplc);
                String emFs = getString(R.string.emfs);
                String durationS = "2-W/ 4-W/ 6-W/ 3-M/ 6-M";
                String wlearnS = "1.\tConcept of analog & digital electronics\n" +
                        "2.\tBasic Programming\n" +
                        "3.\tMicrocontrollers\n" +
                        "4.\tIO Ports Programming\n" +
                        "5.\tSerial Communication\n" +
                        "6.\tEmbedded system development\n";
                String proS = "1.\tPropeller display of Time / Message\n" +
                        "2.\tVehicle Tracking By GPS – GSM\n" +
                        "3.\tAuto Intensity Control of Street Lights\n" +
                        "4.\tAuto Metro Train to Shuttle Between Stations\n" ;
                String recS = "Basic programming knowledge of C should be awesome";

                Intent intent = new Intent(getApplicationContext(), CourseDetailsActivity.class);
                intent.putExtra("im", emIm);
                intent.putExtra("a", "EMBEDDED SYSTEM");
                intent.putExtra("b", durationS);
                intent.putExtra("c", "Contact now");
                intent.putExtra("d", emTitle);

                intent.putExtra("wlearn", wlearnS);
                intent.putExtra("pro", proS);
                intent.putExtra("req", recS);
                intent.putExtra("e", emDescription);
                intent.putExtra("f", emFs);
                startActivity(intent);
            }
        });
    }
}
